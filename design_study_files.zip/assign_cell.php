<?php
/* ############################################################################
   assign_cell.php: assigns a participant to the cell with the fewest
   COMPLETED participants (ties broken at random).

   Call:  assign_cell.php?pid=PROLIFIC_PID
   Reply: {"cell_id": "S03_O4", "method": "server"}

   - A participant who reloads the page gets the same cell back.
   - Cells handed out in the last PENDING_MINUTES but not yet completed are
     counted as "in progress", so participants starting at the same moment
     are spread across cells instead of all landing in the same one.
   - A pending assignment that is never completed (returned or timed out on
     Prolific) expires after PENDING_MINUTES and the cell is free again.
   State is kept in cell_counts.json next to this file; the web server must be
   able to write to this folder.
   ############################################################################ */

const PENDING_MINUTES = 60;   // match your Prolific completion time limit
const STATE_FILE = __DIR__ . '/cell_counts.json';

header('Content-Type: application/json');
header('Cache-Control: no-store');

$pid = isset($_GET['pid']) ? preg_replace('/[^A-Za-z0-9_\-]/', '', $_GET['pid']) : '';
if ($pid === '') { $pid = 'anon_' . bin2hex(random_bytes(6)); }

// All 60 cells: S01..S10 x O1..O6
$cells = [];
for ($s = 1; $s <= 10; $s++) {
  for ($o = 1; $o <= 6; $o++) {
    $cells[] = sprintf('S%02d_O%d', $s, $o);
  }
}

$fp = fopen(STATE_FILE, 'c+');
if (!$fp || !flock($fp, LOCK_EX)) {
  http_response_code(500);
  echo json_encode(['error' => 'cannot lock state file']);
  exit;
}

$raw = stream_get_contents($fp);
$state = $raw ? json_decode($raw, true) : null;
if (!is_array($state)) { $state = ['completed' => [], 'pending' => []]; }
foreach ($cells as $c) {
  if (!isset($state['completed'][$c])) { $state['completed'][$c] = 0; }
}

// Drop expired pending assignments
$now = time();
foreach ($state['pending'] as $p => $info) {
  if ($now - $info['t'] > PENDING_MINUTES * 60) { unset($state['pending'][$p]); }
}

if (isset($state['pending'][$pid])) {
  // Same participant reloading: keep the same cell
  $cell = $state['pending'][$pid]['cell'];
} else {
  // Load = completed + in progress; choose the lowest, ties at random
  $load = [];
  foreach ($cells as $c) { $load[$c] = $state['completed'][$c]; }
  foreach ($state['pending'] as $info) { $load[$info['cell']] += 1; }
  $min = min($load);
  $candidates = array_keys(array_filter($load, function ($v) use ($min) { return $v === $min; }));
  $cell = $candidates[random_int(0, count($candidates) - 1)];
  $state['pending'][$pid] = ['cell' => $cell, 't' => $now];
}

ftruncate($fp, 0);
rewind($fp);
fwrite($fp, json_encode($state, JSON_PRETTY_PRINT));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

echo json_encode(['cell_id' => $cell, 'method' => 'server']);
