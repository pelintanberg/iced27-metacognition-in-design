<?php
/* ############################################################################
   complete_cell.php: marks a participant's cell as completed.
   Called once, at the end of the study.

   Call:  complete_cell.php?pid=PROLIFIC_PID
   Reply: {"ok": true, "cell_id": "S03_O4"}
   Only completions count towards a cell's total (see assign_cell.php).
   ############################################################################ */

const STATE_FILE = __DIR__ . '/cell_counts.json';

header('Content-Type: application/json');
header('Cache-Control: no-store');

$pid = isset($_GET['pid']) ? preg_replace('/[^A-Za-z0-9_\-]/', '', $_GET['pid']) : '';

$fp = fopen(STATE_FILE, 'c+');
if (!$fp || !flock($fp, LOCK_EX)) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'cannot lock state file']);
  exit;
}

$raw = stream_get_contents($fp);
$state = $raw ? json_decode($raw, true) : null;
if (!is_array($state)) { $state = ['completed' => [], 'pending' => [], 'done' => []]; }
if (!isset($state['done'])) { $state['done'] = []; }

$cell = null;
if ($pid !== '' && isset($state['pending'][$pid])) {
  $cell = $state['pending'][$pid]['cell'];
  if (!isset($state['completed'][$cell])) { $state['completed'][$cell] = 0; }
  $state['completed'][$cell] += 1;
  $state['done'][$pid] = ['cell' => $cell, 't' => time()];
  unset($state['pending'][$pid]);
}

ftruncate($fp, 0);
rewind($fp);
fwrite($fp, json_encode($state, JSON_PRETTY_PRINT));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

echo json_encode(['ok' => $cell !== null, 'cell_id' => $cell]);
